NIBIN MATHAI PORTFOLIO — NO-API CHATBOT

This version uses a simple browser-based question-and-answer chatbot. It does not require an OpenAI key, Gemini key, Netlify Function, or paid AI API.

HOW IT WORKS
- Answers common questions about experience, HACCP, skills, training, location, and contact details using built-in responses.
- Resume requests open the visitor’s email app with a prefilled email to nibin.varky@gmail.com.
- Unknown questions receive a helpful prompt to ask about supported topics or email directly.

DEPLOYMENT
Upload/deploy the included index.html as your website’s homepage. This chatbot is entirely client-side, so no serverless function or environment variables are required.

LIMITATION
This is not a generative AI chatbot. It matches common question topics and returns predefined answers, so it works without API costs but cannot answer arbitrary questions like a full AI model.
